import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	//Declare Variables
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {
		//Initialize variables to empty objects
		card = new CardLayout();
		cardText = new CardLayout();
		slidePane = new JPanel();
		textPane = new JPanel();
		//I edited the background color from blue to red.
		textPane.setBackground(Color.RED);
		//I edited the size of the text window to fit my text better.
		textPane.setBounds(10, 500, 770, 70);
		textPane.setVisible(true);
		buttonPane = new JPanel();
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		//Setup frame attributes
		//I set the window size to fit my layout.
		setSize(820, 650);
		setLocationRelativeTo(null);
		//I edited the title to include my name.
		setTitle("Top 5 Destinations SlideShow by Michael Haggerty");
		getContentPane().setLayout(new BorderLayout(10, 50));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Setting the layouts for the panels
		slidePane.setLayout(card);
		textPane.setLayout(cardText);
		
		//logic to add each of the slides and text
		//I changed the loop value from 5 to 15 to fit the additional data.
		for (int i = 1; i <= 15; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();
			lblSlide.setText(getResizeIcon(i));
			lblTextArea.setText(getTextDescription(i));
			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
		//I changed "Previous" to "Go Back" to show that I could edit buttons.
		btnPrev.setText("Go Back");
		btnPrev.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);
		//I changed "Next" to "Advance" to show that I could edit buttons.
		btnNext.setText("Advance");
		btnNext.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}
	
	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the images
	 */
	//I changed the default images to the new ones from Wikimedia Commons.
	private String getResizeIcon(int i) {
		String image = ""; 
		if (i==1){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Colorful_neon_street_signs_in_Kabukicho,_Shinjuku,_Tokyo.jpg") + "'</body></html>";
		} else if (i==2){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Colorful_neon_street_signs_in_Kabukicho,_Shinjuku,_Tokyo.jpg") + "'</body></html>";
		} else if (i==3){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Colorful_neon_street_signs_in_Kabukicho,_Shinjuku,_Tokyo.jpg") + "'</body></html>";
		} else if (i==4){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/630px-Welcome_to_Fabulous_Las_Vegas.jpg") + "'</body></html>";
		} else if (i==5){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/630px-Welcome_to_Fabulous_Las_Vegas.jpg") + "'</body></html>";
	    } else if (i==6){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/630px-Welcome_to_Fabulous_Las_Vegas.jpg") + "'</body></html>";
	    } else if (i==7){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Lodon_Wheel_-_panoramio.jpg") + "'</body></html>";
	    } else if (i==8){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Lodon_Wheel_-_panoramio.jpg") + "'</body></html>";
	    } else if (i==9){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Lodon_Wheel_-_panoramio.jpg") + "'</body></html>";
	    } else if (i==10){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-New_York_City_at_night_HDR.jpg") + "'</body></html>";
	    } else if (i==11){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-New_York_City_at_night_HDR.jpg") + "'</body></html>";
	    } else if (i==12){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-New_York_City_at_night_HDR.jpg") + "'</body></html>";
	    } else if (i==13){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Arc_de_triomphe_du_carrousel_in_Paris_France.jpg") + "'</body></html>";
	    } else if (i==14){
			image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Arc_de_triomphe_du_carrousel_in_Paris_France.jpg") + "'</body></html>";
		} else if (i==15){
	    	image = "<html><body><img width= '800' height='500' src='" + getClass().getResource("/resources/640px-Arc_de_triomphe_du_carrousel_in_Paris_France.jpg") + "'</body></html>";
    }
		return image;
	}
	
	/**
	 * Method to get the text values
	 */
	//I added in location descriptions, wellness information, and the image credits from Wikimedia Commons.
	private String getTextDescription(int i) {
		String text = ""; 
		if (i==1){
			text = "<html><body><font size='4'><font color = 'WHITE'>#1 Tokyo, Japan.</font> <br><font color = 'WHITE'>Japan's capital city features a perfect blend of traditional culture and modern innovation.</body></html>";
		} else if (i==2){
			text = "<html><body><font size='4'><font color = 'WHITE'>Additional Wellness Info:</font> <br><font color = 'WHITE'>Tokyo also features the famous Capsule Hotel for a unique lodging experience.</body></html>";
		} else if (i==3){
			text = "<html><body><font size='4'><font color = 'WHITE'>Image Credit:</font> <br><font color = 'WHITE'>Basile Morin - Own work, CC BY-SA 4.0, https://commons.wikimedia.org/w/index.php?curid=80020485</body></html>";
		} else if (i==4){
			text = "<html><body><font size='4'><font color = 'WHITE'>#2 Las Vegas, Nevada, United States.</font> <br><font color = 'WHITE'>People coming here can either try to strike it rich at one of the many casinos or relax and see performances by world-class magicians, acrobats, and more.</body></html>";
		} else if (i==5){
			text = "<html><body><font size='4'><font color = 'WHITE'>Additional Wellness Info:</font> <br><font color = 'WHITE'>Las Vegas is also home to many 5-star hotels and restaurants for guests to enjoy.</body></html>";
		} else if (i==6){
			text = "<html><body><font size='4'><font color = 'WHITE'>Image Credit:</font> <br><font color = 'WHITE'>Thomas Wolf, www.foto-tw.de, CC BY-SA 3.0, https://commons.wikimedia.org/w/index.php?curid=43851150</body></html>";
		} else if (i==7){
			text = "<html><body><font size='4'><font color = 'WHITE'>#3 London, England, United Kingdom.</font> <br><font color = 'WHITE'>Go for a spin on the London Wheel or see various important landmarks by double-decker bus, including Big Ben and the Houses of Parliament.</body></html>";
		} else if (i==8){
			text = "<html><body><font size='4'><font color = 'WHITE'>Additional Wellness Info:</font> <br><font color = 'WHITE'>London also includes Hyde Park, where guests can just enjoy some peace and quiet.</body></html>";
		} else if (i==9){
			text = "<html><body><font size='4'><font color = 'WHITE'>Image Credit:</font> <br><font color = 'WHITE'>office, CC BY-SA 3.0, https://commons.wikimedia.org/w/index.php?curid=53303387</body></html>";
		} else if (i==10){
			text = "<html><body><font size='4'><font color = 'WHITE'>#4 New York City, New York, United States.</font> <br><font color = 'WHITE'>Whether it's high-quality stage shows on Broadway or viewing various landmarks such as the Statue of Liberty or the Empire State Building, the economic center of America has something for everyone.</body></html>";
		} else if (i==11){
			text = "<html><body><font size='4'><font color = 'WHITE'>Additional Wellness Info:</font> <br><font color = 'WHITE'>For those looking to get away from the bustling streets, you can shop in many of the city's famous stores or relax in Central Park.</body></html>";
		} else if (i==12){
			text = "<html><body><font size='4'><font color = 'WHITE'>Image Credit:</font> <br><font color = 'WHITE'>Paulo Barcellos Jr. - https://www.flickr.com/photos/paulobar/230134559/, CC BY-SA 2.0, https://commons.wikimedia.org/w/index.php?curid=1150291</body></html>";
		} else if (i==13){
			text = "<html><body><font size='4'><font color = 'WHITE'>#5 Paris, France.</font> <br><font color = 'WHITE'>People can enjoy the bustling street life or view iconic landmarks such as the Eiffel Tower and the Arc de Triomphe.</body></html>";
		} else if (i==14){
			text = "<html><body><font size='4'><font color = 'WHITE'>Additional Wellness Info:</font> <br><font color = 'WHITE'>People can also browse art in the Louvre or buy some of France's world-famous wine or perfumes.</body></html>";
		} else if (i==15){
			text = "<html><body><font size='4'><font color = 'WHITE'>Image Credit:</font> <br><font color = 'WHITE'>Tim Adams - Own work, CC BY 3.0, https://commons.wikimedia.org/w/index.php?curid=53062615</body></html>";
		}
		return text;
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {

			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}