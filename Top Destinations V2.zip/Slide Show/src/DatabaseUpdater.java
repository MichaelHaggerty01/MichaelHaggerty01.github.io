import java.util.Scanner;
public class DatabaseUpdater extends SlideShow{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static void main(String[] args) {
		//Capture user input.
		Scanner Scan1 = new Scanner (System.in);
		Scanner sc = new Scanner(System.in);
		//Save user input into database.
		for (int i = 0; i < 5; i++) {
			//Loop for obtaining data
			System.out.printf("Enter a city name: ");
			SlideShow.name[i] = sc.nextLine();
			System.out.printf("Enter a fitting image filename within your \"resources\" folder: ");
			SlideShow.img[i] = sc.nextLine();
			System.out.printf("Give credit for your image: ");
			SlideShow.credit[i] = sc.nextLine();
			System.out.printf("Enter some thoughts on the chosen city: ");
			SlideShow.desc[i] = sc.nextLine();
			System.out.printf("Enter some additional, wellness-based thoughts: ");
			SlideShow.well[i] = sc.nextLine();
		}
		//Stop obtaining user input.
		sc.close();
		Scan1.close();
		//Start SlideShow.
		System.out.println("Now Running: Top Destinations Slideshow");
		SlideShow ss = new SlideShow();
		ss.setVisible(true);
	}
}
